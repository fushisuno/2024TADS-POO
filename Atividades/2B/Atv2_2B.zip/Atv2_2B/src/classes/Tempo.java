package classes;

public class Tempo {
	public long quantidade() {
		return 0;
	}
	
	@Override
	public String toString() {
		return "";
	}

}